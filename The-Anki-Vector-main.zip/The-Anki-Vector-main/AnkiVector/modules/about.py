__help__ = """
** Anki Vector - A Powerful Telegram Group Manager 🎶 **

Powerful Abilities

• Group Voice Chat Music Play ❤️
• File To Link and URL Upload 📂
• Youtube Downloader 🎵

Developers [TeamAnkiVector🇱🇰](https://t.me/TeamAnkiVector)

**~ @TheAnkiVectorBot**
"""
__mod_name__ = "About"
